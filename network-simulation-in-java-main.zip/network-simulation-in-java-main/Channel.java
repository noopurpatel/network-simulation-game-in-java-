package networkSimulation;

public class Channel extends Packets {

}
